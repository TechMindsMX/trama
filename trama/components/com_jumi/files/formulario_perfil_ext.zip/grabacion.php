<?php
defined('_JEXEC') or die( 'Restricted access' );

$tabla = "perfilx_respuestas";
// $campo = "respuestaPerfil";
// $valor = "1,2,3,4";
// $idjoom = "570";

$var = $_POST;
	foreach ($var as $key => $value) {
		if (is_numeric($value) && ($key != 'usuario')) {
			$valor[] = $value;
		}
		elseif ($key == 'usuario') {
			$idjoom = $value;
		}
		elseif ($key == 'campo') {
			$campo = $value;
		}
	}
$valor = implode(',', $valor);

function insertar($tabla, $campo, $valor, $idjoom){

	$db = JFactory::getDbo();

	$query = $db->getQuery(true);

	$columns = array($campo, 'users_id');
	$values = array($db->quote($valor), $db->quote($idjoom));
	
	$query
		->insert($db->quoteName($tabla))
		->columns($db->quoteName($columns))
		->values(implode(',', $values));
	
	$db->setQuery($query);
	$db->query();
	
	echo $query;
}

function actualizar($tabla, $campo, $valor, $idjoom){

	$db = JFactory::getDbo();

	$query = $db->getQuery(true);

	$fields = (
		'`'.$campo.'` = \'' .$valor.'\'');
	
	$conditions = (
		'`users_id` = ' .$idjoom);
	
	$query->update($db->quoteName($tabla))->set($fields)->where($conditions);
	
	$db->setQuery($query);
	$db->query();
}

function buscarUsuarioExistente($tabla, $idjoom){

	$db = JFactory::getDbo();

	$query = $db->getQuery(true);

	$query
		->select('*')
		->from($tabla)
		->where('users_id = ' .$idjoom);

	$db->setQuery($query);
	
	$total = $db->loadRow($query);

	return $total;
}

function dataRecord($tabla, $campo, $valor, $idjoom){
		$resultado = buscarUsuarioExistente($tabla, $idjoom);
//		var_dump($resultado);
	//	exit;
		
		if(empty($resultado)){
			insertar($tabla, $campo, $valor, $idjoom);
		}else{
			actualizar($tabla, $campo, $valor, $idjoom);
		}
}

dataRecord($tabla, $campo, $valor, $idjoom);
?>